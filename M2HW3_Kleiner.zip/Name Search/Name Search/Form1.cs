﻿/*
* 19 September 2018
* CSC 253
* Kenneth Kleiner
* This program allows user to enter a name and see if it is
* one of the most popular names for the first decade of the 2000s.
* 
* I tried sorting the array but ran into some problems.
* I may come back to this at a later date.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Name_Search
{
    public partial class Form1 : Form
    {
        // global variables
        List<string> girlNames = new List<string>();
        List<string> boyNames = new List<string>();

        
        public Form1()
        {
            InitializeComponent();

            // load lists
            // first boys
            try
            {
                // variable to store name from list
                string nameIn;

                // declare streamreader
                StreamReader inputFile;

                // open file
                inputFile = File.OpenText("BoyNames.txt");

                // read file
                while (!inputFile.EndOfStream)
                {
                    // get name
                    nameIn = inputFile.ReadLine();

                    // add name to list
                    boyNames.Add(nameIn);
                }

                // close boy file
                inputFile.Close();

            }
            catch (Exception ex)
            {
                // display error message
                MessageBox.Show(ex.Message);
            }
            // second girls
            try
            {
                // variable to store name from list
                string nameIn;

                // declare streamreader
                StreamReader inputFile;

                // open file
                inputFile = File.OpenText("GirlNames.txt");

                // read file
                while (!inputFile.EndOfStream)
                {
                    // get name
                    nameIn = inputFile.ReadLine();

                    // add name to list
                    girlNames.Add(nameIn);
                }

                // close boy file
                inputFile.Close();

            }
            catch (Exception ex)
            {
                // display error message
                MessageBox.Show(ex.Message);
            }

            // used during testing
            // MessageBox.Show("boys names - " + boyNames.Count);
            // MessageBox.Show("girls names - " + girlNames.Count);

            // sort lists - could not get to work
            // I either got a ref(erence) error or it was telling me 
            // something about sort(T).  I may have to do some research on this.
            // Maybe through the iamtimcorey youtube channel.
            //
            //listSort(boyNames);
            //listSort(girlNames);

            //foreach (string nameInList in boyNames)
            //{
            //    MessageBox.Show(nameInList);
            //}
            //foreach (string nameInList in girlNames)
            //{
            //    MessageBox.Show(nameInList);
            //}

        }

        //private void listSort(List<string> iList)
        //{
        //    int minIndex;   // smallest subscript in scanned area
        //    string minValue;    // smallest value in scanned area

        //    for (int startScan = 0; startScan < iList.Count; startScan++)
        //    {
        //        minIndex = startScan;
        //        minValue = iList[startScan];

        //        for (int index = startScan + 1; index < iList.Count; index++)
        //        {
        //            if (String.Compare(iList[index], minValue) < 0) // iList[index] < minValue)
        //            {
        //                minValue = iList[index];
        //                minIndex = index;
        //            }
        //        }
        //        Swap(iList[minIndex], iList[startScan]);
        //    }


//            throw new NotImplementedException();
        //}

        // sort list
        //private void listSort(List iList)
        //{
        //    int minIndex;   // smallest subscript in scanned area
        //    string minValue;    // smallest value in scanned area

        //    for (int startScan = 0; startScan < iList.Count; startScan++)
        //    {
        //        minIndex = startScan;
        //        minValue = iList[startScan];

        //        for (int index = startScan+1; index < iList.Count; index++)
        //        {
        //            if (iList[index] < minValue)
        //            {
        //                minValue = iList[index];
        //                minIndex = index;
        //            }
        //        }
        //        Swap(ref iList[minIndex], ref iList[startScan]);
        //    }
        //}

        //private void Swap(string a, string b)
        //{
        //    string temp = a;
        //    a = b;
        //    b = temp;
        //}

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            nameFoundLabel.Text = "";
            nameTextBox.Text = "";
        }

        // process entered name using sequential search
        private void searchButton_Click(object sender, EventArgs e)
        {
            // if nothing entered display message
            if (nameTextBox.Text == "")
            {
                MessageBox.Show("Please enter a name");
            }
            else
            // Jordan is in both lists
            {
                string nameChecked = nameTextBox.Text;
                // process through boy names
                foreach (string nameInList in boyNames)
                {
                    if (nameInList == nameChecked)
                    {
                        nameFoundLabel.Text += "The name was found in the boys list. ";
                    }
                }
                // process through girl names
                foreach (string nameInList in girlNames)
                {
                    if (nameInList == nameChecked)
                    {
                        nameFoundLabel.Text += "The name was found in the girls list. ";
                    }
                }

            }
        }
    }

    // while trying to sort array, this code was put it by VS when I clicked on one of the options for fixing error
    //internal class List
    //{
    //}
}
