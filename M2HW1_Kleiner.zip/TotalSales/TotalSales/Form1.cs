﻿/**
* 6 September 2018
* CSC 253
* Kenneth Kleiner
* Program reads through a file, reading daily sales, and displays total
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TotalSales
{
    public partial class Form1 : Form
    {
        double totalSales = 0.0;
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // The GetFileName method get a filename from user and 
        // assigns it to the variable passed as an argument

        private void GetFileName(out string selectedFile)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                selectedFile = openFileDialog.FileName;
            }
            else
            {
                selectedFile = "";
            }
        }

        // GetDailySales method accepts a filename as argument, opens file, and displays content in ListBox control.
        private void GetDailySales(string filename)
        {
            try
            {


                // variable to hold daily sales
                double dailySales;
                string dailySalesIn;

                // declare StreamReader variable
                StreamReader inputFile;

                // open file and get StreamReader object
                inputFile = File.OpenText(filename);

                // clear anything in the ListBox
                dailySalesListBox.Items.Clear();

                // read the file
                while (!inputFile.EndOfStream)
                {
                    // get daily sales
                    dailySalesIn = inputFile.ReadLine();
                    if (double.TryParse(dailySalesIn, out dailySales))
                    {
                        totalSales = totalSales + dailySales;
                    }
                    else
                    {
                        // display error
                        MessageBox.Show("Invalid Sales Amount");
                    }

                    // add daily sales to ListBox
                    dailySalesListBox.Items.Add(dailySales);
                }

                // close file
                inputFile.Close();
            }
            catch (Exception ex)
            {
                // display an error message
                MessageBox.Show(ex.Message);
            }
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            string filename;  // to hold the filename

            // Get the filename from user
            GetFileName(out filename);

            // Get daily sales from file
            GetDailySales(filename);

            // Display total sales
            dailySalesLabel.Text = totalSales.ToString("c");
        }
    }
}
