﻿/**
* 29 August 2018
* CSC 253
* Kenneth Kleiner
* Program calculates Kinetic energy based on user inputs and has a function call
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KineticEnergy
{
    public partial class Form1 : Form
    {
        double KE;
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void KineticEnergy(double m, double v)
        {
            KE = .5 * m * (Math.Pow(v, 2));
        }

        private void calculateEnergyButton_Click(object sender, EventArgs e)
        {
            double mass = double.Parse(massTextBox.Text);
            double velocity = double.Parse(velocityTextBox.Text);

            KineticEnergy(mass, velocity);

            kineticEnergyLabel.Text = "For an object of mass " + mass + "kg and a velocity of " + velocity + " meters/second, the kinetic energy is " + KE + "Joules.;
        }
    }
}
