﻿namespace KineticEnergy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.massLabel = new System.Windows.Forms.Label();
            this.velocityLabel = new System.Windows.Forms.Label();
            this.massTextBox = new System.Windows.Forms.TextBox();
            this.velocityTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateEnergyButton = new System.Windows.Forms.Button();
            this.kineticEnergyLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // massLabel
            // 
            this.massLabel.AutoSize = true;
            this.massLabel.Location = new System.Drawing.Point(13, 33);
            this.massLabel.Name = "massLabel";
            this.massLabel.Size = new System.Drawing.Size(138, 13);
            this.massLabel.TabIndex = 0;
            this.massLabel.Text = "Enter mass of object (in kg):";
            // 
            // velocityLabel
            // 
            this.velocityLabel.AutoSize = true;
            this.velocityLabel.Location = new System.Drawing.Point(12, 59);
            this.velocityLabel.Name = "velocityLabel";
            this.velocityLabel.Size = new System.Drawing.Size(206, 13);
            this.velocityLabel.TabIndex = 1;
            this.velocityLabel.Text = "Enter velocity of object (in meters/second)";
            // 
            // massTextBox
            // 
            this.massTextBox.Location = new System.Drawing.Point(292, 25);
            this.massTextBox.Name = "massTextBox";
            this.massTextBox.Size = new System.Drawing.Size(100, 20);
            this.massTextBox.TabIndex = 2;
            // 
            // velocityTextBox
            // 
            this.velocityTextBox.Location = new System.Drawing.Point(292, 51);
            this.velocityTextBox.Name = "velocityTextBox";
            this.velocityTextBox.Size = new System.Drawing.Size(100, 20);
            this.velocityTextBox.TabIndex = 3;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(317, 227);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateEnergyButton
            // 
            this.calculateEnergyButton.Location = new System.Drawing.Point(16, 193);
            this.calculateEnergyButton.Name = "calculateEnergyButton";
            this.calculateEnergyButton.Size = new System.Drawing.Size(75, 57);
            this.calculateEnergyButton.TabIndex = 5;
            this.calculateEnergyButton.Text = "Calculate Kinetic Energy";
            this.calculateEnergyButton.UseVisualStyleBackColor = true;
            this.calculateEnergyButton.Click += new System.EventHandler(this.calculateEnergyButton_Click);
            // 
            // kineticEnergyLabel
            // 
            this.kineticEnergyLabel.BackColor = System.Drawing.SystemColors.Info;
            this.kineticEnergyLabel.Location = new System.Drawing.Point(16, 113);
            this.kineticEnergyLabel.Name = "kineticEnergyLabel";
            this.kineticEnergyLabel.Size = new System.Drawing.Size(376, 65);
            this.kineticEnergyLabel.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 262);
            this.Controls.Add(this.kineticEnergyLabel);
            this.Controls.Add(this.calculateEnergyButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.velocityTextBox);
            this.Controls.Add(this.massTextBox);
            this.Controls.Add(this.velocityLabel);
            this.Controls.Add(this.massLabel);
            this.Name = "Form1";
            this.Text = "Kinetic Energy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label massLabel;
        private System.Windows.Forms.Label velocityLabel;
        private System.Windows.Forms.TextBox massTextBox;
        private System.Windows.Forms.TextBox velocityTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateEnergyButton;
        private System.Windows.Forms.Label kineticEnergyLabel;
    }
}

