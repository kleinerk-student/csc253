﻿namespace WordCounter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stringEnteredLabel = new System.Windows.Forms.Label();
            this.processButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.wordCountLabel = new System.Windows.Forms.Label();
            this.stringEnteredTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // stringEnteredLabel
            // 
            this.stringEnteredLabel.AutoSize = true;
            this.stringEnteredLabel.Location = new System.Drawing.Point(13, 13);
            this.stringEnteredLabel.Name = "stringEnteredLabel";
            this.stringEnteredLabel.Size = new System.Drawing.Size(144, 13);
            this.stringEnteredLabel.TabIndex = 0;
            this.stringEnteredLabel.Text = "Enter a string to be checked:";
            // 
            // processButton
            // 
            this.processButton.Location = new System.Drawing.Point(16, 174);
            this.processButton.Name = "processButton";
            this.processButton.Size = new System.Drawing.Size(75, 43);
            this.processButton.TabIndex = 2;
            this.processButton.Text = "Process String";
            this.processButton.UseVisualStyleBackColor = true;
            this.processButton.Click += new System.EventHandler(this.processButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(196, 174);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 43);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(106, 174);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 43);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear Form";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // wordCountLabel
            // 
            this.wordCountLabel.BackColor = System.Drawing.SystemColors.Info;
            this.wordCountLabel.Location = new System.Drawing.Point(16, 102);
            this.wordCountLabel.Name = "wordCountLabel";
            this.wordCountLabel.Size = new System.Drawing.Size(255, 23);
            this.wordCountLabel.TabIndex = 5;
            // 
            // stringEnteredTextBox
            // 
            this.stringEnteredTextBox.Location = new System.Drawing.Point(16, 30);
            this.stringEnteredTextBox.Name = "stringEnteredTextBox";
            this.stringEnteredTextBox.Size = new System.Drawing.Size(256, 20);
            this.stringEnteredTextBox.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.wordCountLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.processButton);
            this.Controls.Add(this.stringEnteredTextBox);
            this.Controls.Add(this.stringEnteredLabel);
            this.Name = "Form1";
            this.Text = "Word Count";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label stringEnteredLabel;
        private System.Windows.Forms.Button processButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label wordCountLabel;
        private System.Windows.Forms.TextBox stringEnteredTextBox;
    }
}

