﻿/*
* 26 September 2018
* CSC 253
* Kenneth Kleiner
* Program accepts string from user and then process string to count the words.
* Uses the trim method to get rid of leading and trailing spaces.
* Uses the isWhiteSpace and isPunctuation methods also.
* I added logic to account for multiple spaces in the middle of the string.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordCounter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clear text box and word count label
            stringEnteredTextBox.Text = "";
            wordCountLabel.Text = "";
        }

        private void processButton_Click(object sender, EventArgs e)
        {
            // variables to be used
            int wordCount = 0;
            bool prevCharSpacePunc = false;
            string stringEntered = stringEnteredTextBox.Text.Trim();
            char lastLetter = stringEntered[stringEntered.Length-1];
            
            if (!char.IsPunctuation(lastLetter))
            {
                wordCount = 1;
            }

            foreach (char ch in stringEntered)
            {
                if (!prevCharSpacePunc)
                {
                    // if space or punctuation is encountered and the previos character was a non-space/non-punctuation
                    if ((char.IsWhiteSpace(ch) || char.IsPunctuation(ch)) && !prevCharSpacePunc)
                    {
                        wordCount++;
                        prevCharSpacePunc = true;
                    }
                    else
                    {
                        prevCharSpacePunc = false;
                    }
                }
                else
                {
                    if (char.IsWhiteSpace(ch) || char.IsPunctuation(ch))
                    {
                        prevCharSpacePunc = true;
                    }
                    else
                    {
                        prevCharSpacePunc = false;
                    }
                }
            }
            wordCountLabel.Text = "The number of words in the string is " + wordCount;
        }
    }
}
