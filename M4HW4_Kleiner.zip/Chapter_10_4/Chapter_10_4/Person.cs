﻿/*
* 2 November 2018
* CSC 253
* Kenneth Kleiner
* Fourth use of Inheritance
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10_4
{
    class Person
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public Person()
        {
            Name = "";
            Address = "";
            Phone = "";
        }

    }
}
