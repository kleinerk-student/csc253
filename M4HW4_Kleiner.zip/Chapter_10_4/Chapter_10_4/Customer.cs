﻿/*
* 2 November 2018
* CSC 253
* Kenneth Kleiner
* Fourth use of Inheritance
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10_4
{
    class Customer : Person
    {
        public int CustomerNumber { get; set; }
        public bool MailingList { get; set; }
        public Customer()
        {
            CustomerNumber = 0;
            MailingList = false;
        }
    }
}
