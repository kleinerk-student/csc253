﻿/*
* 2 November 2018
* CSC 253
* Kenneth Kleiner
* Fourth use of Inheritance
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter_10_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetCustomerData(Customer customer)
        {
            // get data from form
            customer.Name = nameTextBox.Text;
            customer.Address = addressTextBox.Text;
            customer.Phone = phoneTextBox.Text;
            customer.CustomerNumber = int.Parse(custNumberTextBox.Text.ToString());
            if (mailingListCheckBox.Checked)
            {
                customer.MailingList = true;
            }
            else
            {
                customer.MailingList = false;
            }
        }

        private void processButton_Click(object sender, EventArgs e)
        {
            // display data to form from Customer class which includes Person class
            Customer newCust = new Customer();
            GetCustomerData(newCust);

            displayNameTextBox.Text = newCust.Name;
            displayAddressTextBox.Text = newCust.Address;
            displayPhoneTextBox.Text = newCust.Phone;
            displayCustNumTextBox.Text = newCust.CustomerNumber.ToString();
            if (newCust.MailingList == true)
            {
                displayMailingListLabel.Text = "This customer is on the mailing list.";
            }
            else
            {
                displayMailingListLabel.Text = "Ask customer if they would like to be on our mailing list.";
            }

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clear input fields
            nameTextBox.Text = "";
            addressTextBox.Text = "";
            phoneTextBox.Text = "";
            custNumberTextBox.Text = "";
            mailingListCheckBox.Checked = false;

            // clear output fields
            displayNameTextBox.Text = "";
            displayAddressTextBox.Text = "";
            displayPhoneTextBox.Text = "";
            displayCustNumTextBox.Text = "";
            displayMailingListLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close project
            this.Close();
        }
    }
}
