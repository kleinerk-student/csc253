﻿namespace Chapter_10_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.personDataLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.customerLabel = new System.Windows.Forms.Label();
            this.custNumberLabel = new System.Windows.Forms.Label();
            this.mailingListLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.custNumberTextBox = new System.Windows.Forms.TextBox();
            this.mailingListCheckBox = new System.Windows.Forms.CheckBox();
            this.displayNameTextBox = new System.Windows.Forms.TextBox();
            this.displayLabel = new System.Windows.Forms.Label();
            this.displayAddressTextBox = new System.Windows.Forms.TextBox();
            this.displayPhoneTextBox = new System.Windows.Forms.TextBox();
            this.displayCustNumTextBox = new System.Windows.Forms.TextBox();
            this.displayMailingListLabel = new System.Windows.Forms.Label();
            this.processButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // personDataLabel
            // 
            this.personDataLabel.AutoSize = true;
            this.personDataLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.personDataLabel.Location = new System.Drawing.Point(13, 13);
            this.personDataLabel.Name = "personDataLabel";
            this.personDataLabel.Size = new System.Drawing.Size(110, 13);
            this.personDataLabel.TabIndex = 0;
            this.personDataLabel.Text = "Person Data Input";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(13, 49);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(35, 13);
            this.nameLabel.TabIndex = 1;
            this.nameLabel.Text = "Name";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(13, 77);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(45, 13);
            this.addressLabel.TabIndex = 2;
            this.addressLabel.Text = "Address";
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(13, 107);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(38, 13);
            this.phoneLabel.TabIndex = 3;
            this.phoneLabel.Text = "Phone";
            // 
            // customerLabel
            // 
            this.customerLabel.AutoSize = true;
            this.customerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customerLabel.Location = new System.Drawing.Point(13, 135);
            this.customerLabel.Name = "customerLabel";
            this.customerLabel.Size = new System.Drawing.Size(123, 13);
            this.customerLabel.TabIndex = 4;
            this.customerLabel.Text = "Customer Data Input";
            // 
            // custNumberLabel
            // 
            this.custNumberLabel.AutoSize = true;
            this.custNumberLabel.Location = new System.Drawing.Point(13, 161);
            this.custNumberLabel.Name = "custNumberLabel";
            this.custNumberLabel.Size = new System.Drawing.Size(91, 13);
            this.custNumberLabel.TabIndex = 5;
            this.custNumberLabel.Text = "Customer Number";
            // 
            // mailingListLabel
            // 
            this.mailingListLabel.AutoSize = true;
            this.mailingListLabel.Location = new System.Drawing.Point(13, 188);
            this.mailingListLabel.Name = "mailingListLabel";
            this.mailingListLabel.Size = new System.Drawing.Size(65, 13);
            this.mailingListLabel.TabIndex = 6;
            this.mailingListLabel.Text = "Mailing List?";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(141, 41);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 7;
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(141, 69);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(100, 20);
            this.addressTextBox.TabIndex = 8;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Location = new System.Drawing.Point(141, 99);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneTextBox.TabIndex = 9;
            // 
            // custNumberTextBox
            // 
            this.custNumberTextBox.Location = new System.Drawing.Point(141, 153);
            this.custNumberTextBox.Name = "custNumberTextBox";
            this.custNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.custNumberTextBox.TabIndex = 10;
            // 
            // mailingListCheckBox
            // 
            this.mailingListCheckBox.AutoSize = true;
            this.mailingListCheckBox.Location = new System.Drawing.Point(141, 188);
            this.mailingListCheckBox.Name = "mailingListCheckBox";
            this.mailingListCheckBox.Size = new System.Drawing.Size(15, 14);
            this.mailingListCheckBox.TabIndex = 11;
            this.mailingListCheckBox.UseVisualStyleBackColor = true;
            // 
            // displayNameTextBox
            // 
            this.displayNameTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayNameTextBox.Location = new System.Drawing.Point(327, 41);
            this.displayNameTextBox.Name = "displayNameTextBox";
            this.displayNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayNameTextBox.TabIndex = 12;
            // 
            // displayLabel
            // 
            this.displayLabel.AutoSize = true;
            this.displayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLabel.Location = new System.Drawing.Point(324, 12);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(115, 13);
            this.displayLabel.TabIndex = 13;
            this.displayLabel.Text = "Display Information";
            // 
            // displayAddressTextBox
            // 
            this.displayAddressTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayAddressTextBox.Location = new System.Drawing.Point(327, 69);
            this.displayAddressTextBox.Name = "displayAddressTextBox";
            this.displayAddressTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayAddressTextBox.TabIndex = 14;
            // 
            // displayPhoneTextBox
            // 
            this.displayPhoneTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayPhoneTextBox.Location = new System.Drawing.Point(327, 98);
            this.displayPhoneTextBox.Name = "displayPhoneTextBox";
            this.displayPhoneTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayPhoneTextBox.TabIndex = 15;
            // 
            // displayCustNumTextBox
            // 
            this.displayCustNumTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayCustNumTextBox.Location = new System.Drawing.Point(327, 153);
            this.displayCustNumTextBox.Name = "displayCustNumTextBox";
            this.displayCustNumTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayCustNumTextBox.TabIndex = 16;
            // 
            // displayMailingListLabel
            // 
            this.displayMailingListLabel.BackColor = System.Drawing.SystemColors.Info;
            this.displayMailingListLabel.Location = new System.Drawing.Point(327, 188);
            this.displayMailingListLabel.Name = "displayMailingListLabel";
            this.displayMailingListLabel.Size = new System.Drawing.Size(100, 57);
            this.displayMailingListLabel.TabIndex = 17;
            // 
            // processButton
            // 
            this.processButton.Location = new System.Drawing.Point(13, 249);
            this.processButton.Name = "processButton";
            this.processButton.Size = new System.Drawing.Size(75, 23);
            this.processButton.TabIndex = 18;
            this.processButton.Text = "Process";
            this.processButton.UseVisualStyleBackColor = true;
            this.processButton.Click += new System.EventHandler(this.processButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(165, 248);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 19;
            this.clearButton.Text = "Clear Form";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(351, 248);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 20;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 303);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.processButton);
            this.Controls.Add(this.displayMailingListLabel);
            this.Controls.Add(this.displayCustNumTextBox);
            this.Controls.Add(this.displayPhoneTextBox);
            this.Controls.Add(this.displayAddressTextBox);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.displayNameTextBox);
            this.Controls.Add(this.mailingListCheckBox);
            this.Controls.Add(this.custNumberTextBox);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.mailingListLabel);
            this.Controls.Add(this.custNumberLabel);
            this.Controls.Add(this.customerLabel);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.personDataLabel);
            this.Name = "Form1";
            this.Text = "Customer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label personDataLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label customerLabel;
        private System.Windows.Forms.Label custNumberLabel;
        private System.Windows.Forms.Label mailingListLabel;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox custNumberTextBox;
        private System.Windows.Forms.CheckBox mailingListCheckBox;
        private System.Windows.Forms.TextBox displayNameTextBox;
        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.TextBox displayAddressTextBox;
        private System.Windows.Forms.TextBox displayPhoneTextBox;
        private System.Windows.Forms.TextBox displayCustNumTextBox;
        private System.Windows.Forms.Label displayMailingListLabel;
        private System.Windows.Forms.Button processButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

