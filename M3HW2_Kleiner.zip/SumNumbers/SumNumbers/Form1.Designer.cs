﻿namespace SumNumbers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.processStringButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.stringEntryLabel = new System.Windows.Forms.Label();
            this.stringEntryTextBox = new System.Windows.Forms.TextBox();
            this.sumOfNumbersLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // processStringButton
            // 
            this.processStringButton.Location = new System.Drawing.Point(13, 211);
            this.processStringButton.Name = "processStringButton";
            this.processStringButton.Size = new System.Drawing.Size(75, 39);
            this.processStringButton.TabIndex = 0;
            this.processStringButton.Text = "Process String";
            this.processStringButton.UseVisualStyleBackColor = true;
            this.processStringButton.Click += new System.EventHandler(this.processStringButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(197, 211);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 39);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(104, 211);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 39);
            this.clearButton.TabIndex = 2;
            this.clearButton.Text = "Clear Form";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // stringEntryLabel
            // 
            this.stringEntryLabel.AutoSize = true;
            this.stringEntryLabel.Location = new System.Drawing.Point(12, 9);
            this.stringEntryLabel.Name = "stringEntryLabel";
            this.stringEntryLabel.Size = new System.Drawing.Size(198, 13);
            this.stringEntryLabel.TabIndex = 3;
            this.stringEntryLabel.Text = "Enter a list of comma-separated numbers";
            // 
            // stringEntryTextBox
            // 
            this.stringEntryTextBox.Location = new System.Drawing.Point(12, 41);
            this.stringEntryTextBox.Name = "stringEntryTextBox";
            this.stringEntryTextBox.Size = new System.Drawing.Size(198, 20);
            this.stringEntryTextBox.TabIndex = 4;
            // 
            // sumOfNumbersLabel
            // 
            this.sumOfNumbersLabel.BackColor = System.Drawing.SystemColors.Info;
            this.sumOfNumbersLabel.Location = new System.Drawing.Point(12, 87);
            this.sumOfNumbersLabel.Name = "sumOfNumbersLabel";
            this.sumOfNumbersLabel.Size = new System.Drawing.Size(260, 42);
            this.sumOfNumbersLabel.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.sumOfNumbersLabel);
            this.Controls.Add(this.stringEntryTextBox);
            this.Controls.Add(this.stringEntryLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.processStringButton);
            this.Name = "Form1";
            this.Text = "Sum of Numbers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button processStringButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label stringEntryLabel;
        private System.Windows.Forms.TextBox stringEntryTextBox;
        private System.Windows.Forms.Label sumOfNumbersLabel;
    }
}

