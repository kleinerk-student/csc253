﻿/*
* 27 September 2018
* CSC 253
* Kenneth Kleiner
* Program to learn more string manipulation
* Had many index issues
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SumNumbers
{
    public partial class Form1 : Form
    {
        // variables used across methods
        string stringEntered;
        decimal total;
        string processString;
        decimal processNumber;
        public Form1()
        {
            InitializeComponent();
        }

        private void processStringButton_Click(object sender, EventArgs e)
        {
            // take out extra spaces at head and tail of string
            stringEntered = stringEntryTextBox.Text.Trim();
            // set total to 0
            total = 0.0m;

            // determine if last character is a comma
            char lastCharacter = stringEntered[stringEntered.Length - 1];
            if (lastCharacter == ',')
            {
                stringEntered = stringEntered.Remove(stringEntered.Length - 1);
            }

            // set location of last comma to end of string
            int indexOfLastComma = stringEntered.Length;

            // while length of string > 0 and there is still a comma in the string do this
            while (stringEntered.Length > 0 && indexOfLastComma != -1)
            {
                // determine actual location of last comma
                indexOfLastComma = stringEntered.LastIndexOf(',', stringEntered.Length - 1);
                // call to function with location of last comma
                addToTotal(indexOfLastComma);
                // if comma found, delete last number from string
                if (indexOfLastComma != -1)
                {
                    stringEntered = stringEntered.Remove(indexOfLastComma);
                }
            }
            // display total
            sumOfNumbersLabel.Text = "The total for the string of numbers is " + total.ToString();
        }

        private void addToTotal(int index)
        {
            // figure out number to process
            processString = stringEntered.Substring(index + 1);
            processNumber = decimal.Parse(processString);
            total += processNumber;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            stringEntryTextBox.Text = "";
            sumOfNumbersLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
