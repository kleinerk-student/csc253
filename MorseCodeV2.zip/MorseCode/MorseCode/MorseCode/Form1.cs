﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MorseCode
{
    struct CharactersEntry
    {
        // public char letter;
        // public string code;
    }
    public partial class Form1 : Form
    {
        const int ROWS = 50;
        const int COLS = 2;
        // string[,] characters = new string[ROWS, COLS];
        string[] letterInArray = new string[ROWS];
        string[] codeInArray = new string[ROWS];

        public Form1()
        {
            InitializeComponent();
            loadArray();
        }

        private void processButton_Click(object sender, EventArgs e)
        {
            string stringIn = entryTextBox.Text.ToUpper();
            displayLabel.Text = "";
            // char letterToProcess = '';

            foreach (char letterToProcess in stringIn)
            {
                for(int index = 0; index < letterInArray.Length; index++)
                {
                    // find index of character
                    // char letterBeingChecked = letterInArray[index];
                    if (letterInArray[index] == letterToProcess.ToString())
                    {
                        displayLabel.Text += codeInArray[index];
                        displayLabel.Text += "|";
                        break;
                    }
                }
            }
        }

        private void loadArray()
        {
            try
            {
                string recordIn;
                StreamReader inputFile;
                char[] delim = { ';' };
                int index = 0;

                inputFile = File.OpenText("MorseCode.txt");

                while (!inputFile.EndOfStream)
                {
                    recordIn = inputFile.ReadLine();

                    string[] tokens = recordIn.Split(delim);

                    letterInArray[index] = tokens[0];
                    codeInArray[index] = tokens[1];

                    index++;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            entryTextBox.Text = "";
            displayLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
