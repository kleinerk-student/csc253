﻿/**
* 30 August 2018
* CSC 253
* Kenneth Kleiner
* Get us back into classes and array processing
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RetailItem
{
    public partial class Form1 : Form
    {
//        private RetailItem retail[0] = new RetailItem("Jacket", 12, 59.95);
//        private RetailItem retail[1] = new RetailItem("Jeans", 40, 34.95);
//        private RetailItem retail[2] = new RetailItem("Shirt", 20, 24.95);

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void executeButton_Click(object sender, EventArgs e)
        {
            // creates 3 element array of RetailItems
            RetailItem[] retail = new RetailItem[3];

            // set values for items
            retail[0] = new RetailItem("Jacket", 12, 59.95);
            retail[1] = new RetailItem("Jeans", 40, 34.95);
            retail[2] = new RetailItem("Shirt", 20, 24.95);

            // display items with MessageBox for speed control
            for (int index = 0; index < retail.Length; index++)
            {
                descriptionDisplayLabel.Text = retail[index].Description;
                unitsOHDisplayLabel.Text = retail[index].UnitsOnHand.ToString();
                priceDisplayLabel.Text = retail[index].Price.ToString("c");

                MessageBox.Show("See next item?");
            }

        }
    }
}
