﻿namespace RetailItem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.executeButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.descriptionDisplayLabel = new System.Windows.Forms.Label();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.unitsOnHandLabel = new System.Windows.Forms.Label();
            this.unitsOHDisplayLabel = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.priceDisplayLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // executeButton
            // 
            this.executeButton.Location = new System.Drawing.Point(12, 227);
            this.executeButton.Name = "executeButton";
            this.executeButton.Size = new System.Drawing.Size(75, 23);
            this.executeButton.TabIndex = 0;
            this.executeButton.Text = "Execute";
            this.executeButton.UseVisualStyleBackColor = true;
            this.executeButton.Click += new System.EventHandler(this.executeButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(197, 227);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // descriptionDisplayLabel
            // 
            this.descriptionDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.descriptionDisplayLabel.Location = new System.Drawing.Point(96, 46);
            this.descriptionDisplayLabel.Name = "descriptionDisplayLabel";
            this.descriptionDisplayLabel.Size = new System.Drawing.Size(176, 23);
            this.descriptionDisplayLabel.TabIndex = 2;
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(24, 56);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(63, 13);
            this.descriptionLabel.TabIndex = 3;
            this.descriptionLabel.Text = "Description:";
            this.descriptionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // unitsOnHandLabel
            // 
            this.unitsOnHandLabel.AutoSize = true;
            this.unitsOnHandLabel.Location = new System.Drawing.Point(7, 101);
            this.unitsOnHandLabel.Name = "unitsOnHandLabel";
            this.unitsOnHandLabel.Size = new System.Drawing.Size(80, 13);
            this.unitsOnHandLabel.TabIndex = 4;
            this.unitsOnHandLabel.Text = "Units On Hand:";
            this.unitsOnHandLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // unitsOHDisplayLabel
            // 
            this.unitsOHDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.unitsOHDisplayLabel.Location = new System.Drawing.Point(93, 91);
            this.unitsOHDisplayLabel.Name = "unitsOHDisplayLabel";
            this.unitsOHDisplayLabel.Size = new System.Drawing.Size(176, 23);
            this.unitsOHDisplayLabel.TabIndex = 5;
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Location = new System.Drawing.Point(51, 132);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(34, 13);
            this.priceLabel.TabIndex = 6;
            this.priceLabel.Text = "Price:";
            // 
            // priceDisplayLabel
            // 
            this.priceDisplayLabel.BackColor = System.Drawing.SystemColors.Info;
            this.priceDisplayLabel.Location = new System.Drawing.Point(92, 132);
            this.priceDisplayLabel.Name = "priceDisplayLabel";
            this.priceDisplayLabel.Size = new System.Drawing.Size(177, 23);
            this.priceDisplayLabel.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.priceDisplayLabel);
            this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.unitsOHDisplayLabel);
            this.Controls.Add(this.unitsOnHandLabel);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.descriptionDisplayLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.executeButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button executeButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label descriptionDisplayLabel;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label unitsOnHandLabel;
        private System.Windows.Forms.Label unitsOHDisplayLabel;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label priceDisplayLabel;
    }
}

