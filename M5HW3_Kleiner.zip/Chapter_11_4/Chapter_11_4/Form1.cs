﻿/*
* 14 November 2018
* CSC 253
* Kenneth Kleiner
* Connecting to DB and allowing searches
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter_11_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.searchDataSet);

        }
        // loads datagrid.  This was created for me in my office.  Not sure why it did not work in ATC156 last night for 11_3
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'searchDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.searchDataSet.Employee);

        }
        // close/exit program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        // shows all records
        private void showAllButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.Fill(this.searchDataSet.Employee);
        }
        // searches/displays records based on text entered in text box
        // Search for 'er' to get multiple records
        private void searchButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.SearchName(this.searchDataSet.Employee, searchTextBox.Text);
        }
    }
}
