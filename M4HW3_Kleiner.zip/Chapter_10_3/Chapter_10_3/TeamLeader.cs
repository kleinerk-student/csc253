﻿/*
* 2 November 2018
* CSC 253
* Kenneth Kleiner
* Looking at inheritance with inheritance
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10_3
{
    class TeamLeader : ProductionWorker
    {
        // Fields
        public decimal MonthlyBonus { get; set; }
        public decimal TrainingHoursRequired { get; set; }
        public decimal TrainingHoursCompleted { get; set; }

        public TeamLeader()
        {
            MonthlyBonus = 0.0m;
            TrainingHoursRequired = 0.0m;
            TrainingHoursCompleted = 0.0m;
        }
    }
}
