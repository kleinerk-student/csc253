﻿namespace Chapter_10_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputLabel = new System.Windows.Forms.Label();
            this.empNumLabel = new System.Windows.Forms.Label();
            this.empNameLabel = new System.Windows.Forms.Label();
            this.prodShiftLabel = new System.Windows.Forms.Label();
            this.prodPayRateLabel = new System.Windows.Forms.Label();
            this.teamMonthBonusLabel = new System.Windows.Forms.Label();
            this.teamReqHoursLabel = new System.Windows.Forms.Label();
            this.teamCompHoursLabel = new System.Windows.Forms.Label();
            this.displayDataLabel = new System.Windows.Forms.Label();
            this.empNameTextBox = new System.Windows.Forms.TextBox();
            this.empNumberTextBox = new System.Windows.Forms.TextBox();
            this.prodShiftTextBox = new System.Windows.Forms.TextBox();
            this.prodPayRateTextBox = new System.Windows.Forms.TextBox();
            this.teamBonusTextBox = new System.Windows.Forms.TextBox();
            this.teamReqHoursTextBox = new System.Windows.Forms.TextBox();
            this.teamCompHoursTextBox = new System.Windows.Forms.TextBox();
            this.displayEmpNumberTextBox = new System.Windows.Forms.TextBox();
            this.displayEmpNameTextBox = new System.Windows.Forms.TextBox();
            this.displayShiftTextBox = new System.Windows.Forms.TextBox();
            this.displayPayRateTextBox = new System.Windows.Forms.TextBox();
            this.displayBonusTextBox = new System.Windows.Forms.TextBox();
            this.displayReqHoursTextBox = new System.Windows.Forms.TextBox();
            this.displayCompHoursTextBox = new System.Windows.Forms.TextBox();
            this.processButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // inputLabel
            // 
            this.inputLabel.AutoSize = true;
            this.inputLabel.Location = new System.Drawing.Point(12, 13);
            this.inputLabel.Name = "inputLabel";
            this.inputLabel.Size = new System.Drawing.Size(123, 13);
            this.inputLabel.TabIndex = 0;
            this.inputLabel.Text = "Input Team Leader Data";
            // 
            // empNumLabel
            // 
            this.empNumLabel.AutoSize = true;
            this.empNumLabel.Location = new System.Drawing.Point(12, 41);
            this.empNumLabel.Name = "empNumLabel";
            this.empNumLabel.Size = new System.Drawing.Size(93, 13);
            this.empNumLabel.TabIndex = 1;
            this.empNumLabel.Text = "Employee Number";
            // 
            // empNameLabel
            // 
            this.empNameLabel.AutoSize = true;
            this.empNameLabel.Location = new System.Drawing.Point(12, 73);
            this.empNameLabel.Name = "empNameLabel";
            this.empNameLabel.Size = new System.Drawing.Size(84, 13);
            this.empNameLabel.TabIndex = 2;
            this.empNameLabel.Text = "Employee Name";
            // 
            // prodShiftLabel
            // 
            this.prodShiftLabel.AutoSize = true;
            this.prodShiftLabel.Location = new System.Drawing.Point(12, 104);
            this.prodShiftLabel.Name = "prodShiftLabel";
            this.prodShiftLabel.Size = new System.Drawing.Size(82, 13);
            this.prodShiftLabel.TabIndex = 3;
            this.prodShiftLabel.Text = "Production Shift";
            // 
            // prodPayRateLabel
            // 
            this.prodPayRateLabel.AutoSize = true;
            this.prodPayRateLabel.Location = new System.Drawing.Point(12, 130);
            this.prodPayRateLabel.Name = "prodPayRateLabel";
            this.prodPayRateLabel.Size = new System.Drawing.Size(105, 13);
            this.prodPayRateLabel.TabIndex = 4;
            this.prodPayRateLabel.Text = "Production Pay Rate";
            // 
            // teamMonthBonusLabel
            // 
            this.teamMonthBonusLabel.AutoSize = true;
            this.teamMonthBonusLabel.Location = new System.Drawing.Point(12, 158);
            this.teamMonthBonusLabel.Name = "teamMonthBonusLabel";
            this.teamMonthBonusLabel.Size = new System.Drawing.Size(77, 13);
            this.teamMonthBonusLabel.TabIndex = 5;
            this.teamMonthBonusLabel.Text = "Monthly Bonus";
            // 
            // teamReqHoursLabel
            // 
            this.teamReqHoursLabel.AutoSize = true;
            this.teamReqHoursLabel.Location = new System.Drawing.Point(12, 184);
            this.teamReqHoursLabel.Name = "teamReqHoursLabel";
            this.teamReqHoursLabel.Size = new System.Drawing.Size(122, 13);
            this.teamReqHoursLabel.TabIndex = 6;
            this.teamReqHoursLabel.Text = "Required Training Hours";
            // 
            // teamCompHoursLabel
            // 
            this.teamCompHoursLabel.AutoSize = true;
            this.teamCompHoursLabel.Location = new System.Drawing.Point(12, 215);
            this.teamCompHoursLabel.Name = "teamCompHoursLabel";
            this.teamCompHoursLabel.Size = new System.Drawing.Size(129, 13);
            this.teamCompHoursLabel.TabIndex = 7;
            this.teamCompHoursLabel.Text = "Completed Training Hours";
            // 
            // displayDataLabel
            // 
            this.displayDataLabel.AutoSize = true;
            this.displayDataLabel.Location = new System.Drawing.Point(320, 13);
            this.displayDataLabel.Name = "displayDataLabel";
            this.displayDataLabel.Size = new System.Drawing.Size(96, 13);
            this.displayDataLabel.TabIndex = 8;
            this.displayDataLabel.Text = "Team Leader Data";
            // 
            // empNameTextBox
            // 
            this.empNameTextBox.Location = new System.Drawing.Point(168, 65);
            this.empNameTextBox.Name = "empNameTextBox";
            this.empNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.empNameTextBox.TabIndex = 10;
            // 
            // empNumberTextBox
            // 
            this.empNumberTextBox.Location = new System.Drawing.Point(168, 33);
            this.empNumberTextBox.Name = "empNumberTextBox";
            this.empNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.empNumberTextBox.TabIndex = 9;
            // 
            // prodShiftTextBox
            // 
            this.prodShiftTextBox.Location = new System.Drawing.Point(168, 96);
            this.prodShiftTextBox.Name = "prodShiftTextBox";
            this.prodShiftTextBox.Size = new System.Drawing.Size(100, 20);
            this.prodShiftTextBox.TabIndex = 11;
            // 
            // prodPayRateTextBox
            // 
            this.prodPayRateTextBox.Location = new System.Drawing.Point(168, 122);
            this.prodPayRateTextBox.Name = "prodPayRateTextBox";
            this.prodPayRateTextBox.Size = new System.Drawing.Size(100, 20);
            this.prodPayRateTextBox.TabIndex = 12;
            // 
            // teamBonusTextBox
            // 
            this.teamBonusTextBox.Location = new System.Drawing.Point(168, 150);
            this.teamBonusTextBox.Name = "teamBonusTextBox";
            this.teamBonusTextBox.Size = new System.Drawing.Size(100, 20);
            this.teamBonusTextBox.TabIndex = 13;
            // 
            // teamReqHoursTextBox
            // 
            this.teamReqHoursTextBox.Location = new System.Drawing.Point(168, 176);
            this.teamReqHoursTextBox.Name = "teamReqHoursTextBox";
            this.teamReqHoursTextBox.Size = new System.Drawing.Size(100, 20);
            this.teamReqHoursTextBox.TabIndex = 14;
            // 
            // teamCompHoursTextBox
            // 
            this.teamCompHoursTextBox.Location = new System.Drawing.Point(168, 207);
            this.teamCompHoursTextBox.Name = "teamCompHoursTextBox";
            this.teamCompHoursTextBox.Size = new System.Drawing.Size(100, 20);
            this.teamCompHoursTextBox.TabIndex = 15;
            // 
            // displayEmpNumberTextBox
            // 
            this.displayEmpNumberTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayEmpNumberTextBox.Location = new System.Drawing.Point(323, 32);
            this.displayEmpNumberTextBox.Name = "displayEmpNumberTextBox";
            this.displayEmpNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayEmpNumberTextBox.TabIndex = 16;
            // 
            // displayEmpNameTextBox
            // 
            this.displayEmpNameTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayEmpNameTextBox.Location = new System.Drawing.Point(323, 64);
            this.displayEmpNameTextBox.Name = "displayEmpNameTextBox";
            this.displayEmpNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayEmpNameTextBox.TabIndex = 17;
            // 
            // displayShiftTextBox
            // 
            this.displayShiftTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayShiftTextBox.Location = new System.Drawing.Point(323, 95);
            this.displayShiftTextBox.Name = "displayShiftTextBox";
            this.displayShiftTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayShiftTextBox.TabIndex = 18;
            // 
            // displayPayRateTextBox
            // 
            this.displayPayRateTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayPayRateTextBox.Location = new System.Drawing.Point(323, 122);
            this.displayPayRateTextBox.Name = "displayPayRateTextBox";
            this.displayPayRateTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayPayRateTextBox.TabIndex = 19;
            // 
            // displayBonusTextBox
            // 
            this.displayBonusTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayBonusTextBox.Location = new System.Drawing.Point(323, 150);
            this.displayBonusTextBox.Name = "displayBonusTextBox";
            this.displayBonusTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayBonusTextBox.TabIndex = 20;
            // 
            // displayReqHoursTextBox
            // 
            this.displayReqHoursTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayReqHoursTextBox.Location = new System.Drawing.Point(323, 176);
            this.displayReqHoursTextBox.Name = "displayReqHoursTextBox";
            this.displayReqHoursTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayReqHoursTextBox.TabIndex = 21;
            // 
            // displayCompHoursTextBox
            // 
            this.displayCompHoursTextBox.BackColor = System.Drawing.SystemColors.Info;
            this.displayCompHoursTextBox.Location = new System.Drawing.Point(323, 206);
            this.displayCompHoursTextBox.Name = "displayCompHoursTextBox";
            this.displayCompHoursTextBox.Size = new System.Drawing.Size(100, 20);
            this.displayCompHoursTextBox.TabIndex = 22;
            // 
            // processButton
            // 
            this.processButton.Location = new System.Drawing.Point(15, 252);
            this.processButton.Name = "processButton";
            this.processButton.Size = new System.Drawing.Size(75, 23);
            this.processButton.TabIndex = 23;
            this.processButton.Text = "Process";
            this.processButton.UseVisualStyleBackColor = true;
            this.processButton.Click += new System.EventHandler(this.processButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(193, 251);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 24;
            this.clearButton.Text = "Clear Form";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(348, 251);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 25;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 305);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.processButton);
            this.Controls.Add(this.displayCompHoursTextBox);
            this.Controls.Add(this.displayReqHoursTextBox);
            this.Controls.Add(this.displayBonusTextBox);
            this.Controls.Add(this.displayPayRateTextBox);
            this.Controls.Add(this.displayShiftTextBox);
            this.Controls.Add(this.displayEmpNameTextBox);
            this.Controls.Add(this.displayEmpNumberTextBox);
            this.Controls.Add(this.teamCompHoursTextBox);
            this.Controls.Add(this.teamReqHoursTextBox);
            this.Controls.Add(this.teamBonusTextBox);
            this.Controls.Add(this.prodPayRateTextBox);
            this.Controls.Add(this.prodShiftTextBox);
            this.Controls.Add(this.empNumberTextBox);
            this.Controls.Add(this.empNameTextBox);
            this.Controls.Add(this.displayDataLabel);
            this.Controls.Add(this.teamCompHoursLabel);
            this.Controls.Add(this.teamReqHoursLabel);
            this.Controls.Add(this.teamMonthBonusLabel);
            this.Controls.Add(this.prodPayRateLabel);
            this.Controls.Add(this.prodShiftLabel);
            this.Controls.Add(this.empNameLabel);
            this.Controls.Add(this.empNumLabel);
            this.Controls.Add(this.inputLabel);
            this.Name = "Form1";
            this.Text = "Team Leader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label inputLabel;
        private System.Windows.Forms.Label empNumLabel;
        private System.Windows.Forms.Label empNameLabel;
        private System.Windows.Forms.Label prodShiftLabel;
        private System.Windows.Forms.Label prodPayRateLabel;
        private System.Windows.Forms.Label teamMonthBonusLabel;
        private System.Windows.Forms.Label teamReqHoursLabel;
        private System.Windows.Forms.Label teamCompHoursLabel;
        private System.Windows.Forms.Label displayDataLabel;
        private System.Windows.Forms.TextBox empNameTextBox;
        private System.Windows.Forms.TextBox empNumberTextBox;
        private System.Windows.Forms.TextBox prodShiftTextBox;
        private System.Windows.Forms.TextBox prodPayRateTextBox;
        private System.Windows.Forms.TextBox teamBonusTextBox;
        private System.Windows.Forms.TextBox teamReqHoursTextBox;
        private System.Windows.Forms.TextBox teamCompHoursTextBox;
        private System.Windows.Forms.TextBox displayEmpNumberTextBox;
        private System.Windows.Forms.TextBox displayEmpNameTextBox;
        private System.Windows.Forms.TextBox displayShiftTextBox;
        private System.Windows.Forms.TextBox displayPayRateTextBox;
        private System.Windows.Forms.TextBox displayBonusTextBox;
        private System.Windows.Forms.TextBox displayReqHoursTextBox;
        private System.Windows.Forms.TextBox displayCompHoursTextBox;
        private System.Windows.Forms.Button processButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

