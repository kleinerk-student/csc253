﻿/*
* 2 November 2018
* CSC 253
* Kenneth Kleiner
* Looking at inheritance with inheritance
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter_10_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetTeamLeaderData(TeamLeader teamLeader)
        {
            // get data from form
            teamLeader.Number = int.Parse(empNumberTextBox.Text);
            teamLeader.Name = empNameTextBox.Text;
            teamLeader.Shift = int.Parse(prodShiftTextBox.Text);
            teamLeader.PayRate = decimal.Parse(prodPayRateTextBox.Text);
            teamLeader.MonthlyBonus = decimal.Parse(teamBonusTextBox.Text);
            teamLeader.TrainingHoursRequired = decimal.Parse(teamReqHoursTextBox.Text);
            teamLeader.TrainingHoursCompleted = decimal.Parse(teamCompHoursTextBox.Text);
        }

        private void processButton_Click(object sender, EventArgs e)
        {
            // send data from input to output through TeamLeader class
            TeamLeader newTeamLeader = new TeamLeader();
            GetTeamLeaderData(newTeamLeader);

            displayEmpNumberTextBox.Text = newTeamLeader.Number.ToString();
            displayEmpNameTextBox.Text = newTeamLeader.Name;
            if (newTeamLeader.Shift == 1)
            {
                displayShiftTextBox.Text = "Day";
            }
            else
            {
                displayShiftTextBox.Text = "Night";
            }
            displayPayRateTextBox.Text = newTeamLeader.PayRate.ToString();
            displayBonusTextBox.Text = newTeamLeader.MonthlyBonus.ToString();
            displayReqHoursTextBox.Text = newTeamLeader.TrainingHoursRequired.ToString();
            displayCompHoursTextBox.Text = newTeamLeader.TrainingHoursCompleted.ToString();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clear output boxes
            displayBonusTextBox.Text = "";
            displayCompHoursTextBox.Text = "";
            displayEmpNameTextBox.Text = "";
            displayEmpNumberTextBox.Text = "";
            displayPayRateTextBox.Text = "";
            displayReqHoursTextBox.Text = "";
            displayShiftTextBox.Text = "";

            // clear input boxes
            empNameTextBox.Text = "";
            empNumberTextBox.Text = "";
            prodPayRateTextBox.Text = "";
            prodShiftTextBox.Text = "";
            teamBonusTextBox.Text = "";
            teamCompHoursTextBox.Text = "";
            teamReqHoursTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close form
            this.Close();
        }
    }
}
