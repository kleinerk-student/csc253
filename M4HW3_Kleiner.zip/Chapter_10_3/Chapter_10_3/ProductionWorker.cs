﻿/*
* 2 November 2018
* CSC 253
* Kenneth Kleiner
* Looking at inheritance with inheritance
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10_3
{
    class ProductionWorker : Employee
    {
        // Fields
        private int _shift;
        private decimal _payRate;

        // Constructor
        public ProductionWorker()
        {
            _shift = 0;
            _payRate = 0.00m;
        }

        // Shift property
        public int Shift
        {
            get { return _shift; }
            set { _shift = value; }
        }

        // Payrate property
        public decimal PayRate
        {
            get { return _payRate; }
            set { _payRate = value; }
        }
    }
}
