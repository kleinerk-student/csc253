﻿/*
* 14 November 2018
* CSC 253
* Kenneth Kleiner
* Adding multiple queries
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter_11_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void sortPopAscButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPopulationAscending(this.populationDBDataSet.City);
        }

        private void sortPopDescButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByPopulationDescending(this.populationDBDataSet.City);
        }

        private void sortCitiesButton_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByCityAscending(this.populationDBDataSet.City);
        }
        // These would not work with int or decimal
        private void totalButton_Click(object sender, EventArgs e)
        {
            double totalPop;
            totalPop = (double) cityTableAdapter.TotalPopulation();
            displaySpecificDataLabel.Text = totalPop.ToString("n0");
        }

        private void averageButton_Click(object sender, EventArgs e)
        {
            double averagePop;
            averagePop = (double)cityTableAdapter.AveragePopulation();
            displaySpecificDataLabel.Text = averagePop.ToString("n0");
        }

        private void highestButton_Click(object sender, EventArgs e)
        {
            double highestPop;
            highestPop = (double)cityTableAdapter.MaxPopulation();
            displaySpecificDataLabel.Text = highestPop.ToString("n0");
        }

        private void lowestButton_Click(object sender, EventArgs e)
        {
            double lowestPop;
            lowestPop = (double)cityTableAdapter.MinimumPopulation();
            displaySpecificDataLabel.Text = lowestPop.ToString("n0");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void utton_Click(object sender, EventArgs e)
        {
            displaySpecificDataLabel.Text = "";
        }
    }
}
