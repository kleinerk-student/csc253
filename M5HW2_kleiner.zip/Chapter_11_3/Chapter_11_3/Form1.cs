﻿/*
* 13 November 2018
* CSC 253
* Kenneth Kleiner
* Program description: Adding SQL queries to data grid
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter_11_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);
        }

        // this method sorts by pay rate ascending
        private void payRateAscendingButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillByPayRateAscending(this.personnelDataSet.Employee);
        }

        // this method loads the data grid
        private void Form1_Load(object sender, EventArgs e)
        {
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);
        }
        
        // this method closes the project
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // this method sorts by pay rate descending
        private void payRateDescendingButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.FillByPayRateDescending(this.personnelDataSet.Employee);
        }
    }
}
