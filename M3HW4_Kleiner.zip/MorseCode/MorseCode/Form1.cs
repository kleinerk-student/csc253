﻿/*
* 15 October 2018
* CSC 253
* Kenneth Kleiner
* Program description:  This program takes in a string and converts to morse code.
*   The morse code is loaded into an array from a file.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MorseCode
{
    public partial class Form1 : Form
    {
        // constant variables
        const int ROWS = 50;    // this is larger than it should be by 10
        const int COLS = 2;
        // variables used in multiple functions
        string[] letterInArray = new string[ROWS];
        string[] codeInArray = new string[ROWS];

        public Form1()
        {
            InitializeComponent();
            loadArray();    // call to load information from file
        }

        private void processButton_Click(object sender, EventArgs e)
        {
            // get data from form and clear converted text box
            string stringIn = entryTextBox.Text.ToUpper();
            stringIn = stringIn.Trim();
            displayLabel.Text = "";
            
            // process string
            foreach (char letterToProcess in stringIn)
            {
                for(int index = 0; index < letterInArray.Length; index++)
                {
                    // find index of character
                    if (letterInArray[index] == letterToProcess.ToString())  // change char to string for comparison
                    {
                        displayLabel.Text += codeInArray[index];
                        displayLabel.Text += "|";   // add pipe symbol to separate character code
                    }
                }
            }
        }

        private void loadArray()
        {
            // open and read file to load array
            try
            {
                string recordIn;
                StreamReader inputFile;
                char[] delim = { ';' }; // can be changed/added to as nessasary
                int index = 0;

                inputFile = File.OpenText("MorseCode.txt"); // file name can be changed

                // process until end of file is reached
                while (!inputFile.EndOfStream)
                {
                    recordIn = inputFile.ReadLine();

                    string[] tokens = recordIn.Split(delim);
                    // load column 1 into letter, load column 2 into code
                    letterInArray[index] = tokens[0];
                    codeInArray[index] = tokens[1];

                    index++;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // clear input and output text
        private void clearButton_Click(object sender, EventArgs e)
        {
            entryTextBox.Text = "";
            displayLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
