﻿/*
* 15 September 2018 - Yes, I know it is a day later than the listed due date.
* CSC 253
* Kenneth Kleiner
* This program uses two (2) files to list teams that have won the world series and when chosen, 
* to display how many times they have won between 1903-2012, inclusive.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WorldSeriesWinners
{
    public partial class Form1 : Form
    {
        // list for winner names for searching
        List<string> winnersList = new List<string>();

        // variables
        string teamSelected;
        int indexChosen;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void loadTeamsButton_Click(object sender, EventArgs e)
        {
            // this section processes the Teams file
            try
            {
                // variable to hold team names
                string teamName;

                // declare streamreader
                StreamReader inputFile;

                // open file
                inputFile = File.OpenText("Teams.txt");

                // clear teams listbox
                teamsListBox.Items.Clear();

                // read file
                while (!inputFile.EndOfStream)
                {
                    // get team name
                    teamName = inputFile.ReadLine();

                    // add team name to listbox
                    teamsListBox.Items.Add(teamName);
                }

                // close teams file
                inputFile.Close();
            }
            catch (Exception ex)
            {
                // display error message
                MessageBox.Show(ex.Message);
            }

            // this section processes the winners file
            try
            {
                // variable to hold team names
                string winners;

                // declare streamreader
                StreamReader inputFile;

                // open file
                inputFile = File.OpenText("WorldSeriesWinners.txt");

                // read file and add to list
                while (!inputFile.EndOfStream)
                {
                    // get winners name
                    winners = inputFile.ReadLine();

                    // add winners name to array/list
                    winnersList.Add(winners);
                }

                // close teams file
                inputFile.Close();
            }
            catch (Exception ex)
            {
                // display error message
                MessageBox.Show(ex.Message);
            }
        }

        private void processChoicebutton_Click(object sender, EventArgs e)
        {
            if (teamsListBox.SelectedIndex != -1)
            {
                // compare selected team from listbox to list 
                teamSelected = teamsListBox.SelectedItem.ToString();
                int timesWon = 0;
                // process team
                foreach (string team in winnersList)
                {
                    if (teamSelected == team)
                    {
                        timesWon += 1;
                    }
                }
                timesWonLabel.Text = ("The " + teamSelected + " have won " + timesWon + " time(s).");
            }
            else
            {
                MessageBox.Show("Please choose a team");
            }
        }
    }
}
