﻿namespace WorldSeriesWinners
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.teamsListBox = new System.Windows.Forms.ListBox();
            this.timesWonLabel = new System.Windows.Forms.Label();
            this.loadTeamsButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.processChoicebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // teamsListBox
            // 
            this.teamsListBox.FormattingEnabled = true;
            this.teamsListBox.Location = new System.Drawing.Point(13, 25);
            this.teamsListBox.Name = "teamsListBox";
            this.teamsListBox.Size = new System.Drawing.Size(370, 95);
            this.teamsListBox.TabIndex = 0;
            // 
            // timesWonLabel
            // 
            this.timesWonLabel.BackColor = System.Drawing.SystemColors.Info;
            this.timesWonLabel.Location = new System.Drawing.Point(13, 144);
            this.timesWonLabel.Name = "timesWonLabel";
            this.timesWonLabel.Size = new System.Drawing.Size(370, 23);
            this.timesWonLabel.TabIndex = 1;
            // 
            // loadTeamsButton
            // 
            this.loadTeamsButton.Location = new System.Drawing.Point(13, 171);
            this.loadTeamsButton.Name = "loadTeamsButton";
            this.loadTeamsButton.Size = new System.Drawing.Size(91, 23);
            this.loadTeamsButton.TabIndex = 2;
            this.loadTeamsButton.Text = "Load Teams";
            this.loadTeamsButton.UseVisualStyleBackColor = true;
            this.loadTeamsButton.Click += new System.EventHandler(this.loadTeamsButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(308, 170);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // processChoicebutton
            // 
            this.processChoicebutton.Location = new System.Drawing.Point(161, 171);
            this.processChoicebutton.Name = "processChoicebutton";
            this.processChoicebutton.Size = new System.Drawing.Size(75, 23);
            this.processChoicebutton.TabIndex = 4;
            this.processChoicebutton.Text = "Process Choice";
            this.processChoicebutton.UseVisualStyleBackColor = true;
            this.processChoicebutton.Click += new System.EventHandler(this.processChoicebutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 261);
            this.Controls.Add(this.processChoicebutton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.loadTeamsButton);
            this.Controls.Add(this.timesWonLabel);
            this.Controls.Add(this.teamsListBox);
            this.Name = "Form1";
            this.Text = "World Series Winners";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox teamsListBox;
        private System.Windows.Forms.Label timesWonLabel;
        private System.Windows.Forms.Button loadTeamsButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button processChoicebutton;
    }
}

