﻿/**
* 28 August 2018
* CSC 253
* Kenneth Kleiner
* First program back to see if I remember how to do C#
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookClubPoints
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            booksPurchasedTextBox.Text = "";
            pointsEarnedLabel.Text = "";
        }

        private void pointsEarnedButton_Click(object sender, EventArgs e)
        {
            int booksPurchased;
            booksPurchased = int.Parse(booksPurchasedTextBox.Text);

            switch(booksPurchased)
            {
                case 0:
                    pointsEarnedLabel.Text = "You have earned 0 points this month";
                    break;
                case 1:
                    pointsEarnedLabel.Text = "You have earned 5 points this month";
                    break;
                case 2:
                    pointsEarnedLabel.Text = "You have earned 15 points this month";
                    break;
                case 3:
                    pointsEarnedLabel.Text = "You have earned 30 points this month";
                    break;
                default:
                    pointsEarnedLabel.Text = "You have earned 60 points this month";
                    break;
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
