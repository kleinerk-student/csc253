﻿namespace BookClubPoints
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.booksPurchasedLabel = new System.Windows.Forms.Label();
            this.pointsEarnedLabel = new System.Windows.Forms.Label();
            this.booksPurchasedTextBox = new System.Windows.Forms.TextBox();
            this.pointsEarnedButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // booksPurchasedLabel
            // 
            this.booksPurchasedLabel.AutoSize = true;
            this.booksPurchasedLabel.Location = new System.Drawing.Point(13, 48);
            this.booksPurchasedLabel.Name = "booksPurchasedLabel";
            this.booksPurchasedLabel.Size = new System.Drawing.Size(142, 13);
            this.booksPurchasedLabel.TabIndex = 0;
            this.booksPurchasedLabel.Text = "Enter # of books purchased:";
            // 
            // pointsEarnedLabel
            // 
            this.pointsEarnedLabel.BackColor = System.Drawing.SystemColors.Info;
            this.pointsEarnedLabel.Location = new System.Drawing.Point(13, 113);
            this.pointsEarnedLabel.Name = "pointsEarnedLabel";
            this.pointsEarnedLabel.Size = new System.Drawing.Size(259, 23);
            this.pointsEarnedLabel.TabIndex = 1;
            // 
            // booksPurchasedTextBox
            // 
            this.booksPurchasedTextBox.Location = new System.Drawing.Point(162, 48);
            this.booksPurchasedTextBox.Name = "booksPurchasedTextBox";
            this.booksPurchasedTextBox.Size = new System.Drawing.Size(100, 20);
            this.booksPurchasedTextBox.TabIndex = 2;
            // 
            // pointsEarnedButton
            // 
            this.pointsEarnedButton.Location = new System.Drawing.Point(95, 151);
            this.pointsEarnedButton.Name = "pointsEarnedButton";
            this.pointsEarnedButton.Size = new System.Drawing.Size(95, 57);
            this.pointsEarnedButton.TabIndex = 3;
            this.pointsEarnedButton.Text = "How Many Points Have I Earned?";
            this.pointsEarnedButton.UseVisualStyleBackColor = true;
            this.pointsEarnedButton.Click += new System.EventHandler(this.pointsEarnedButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(16, 217);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 4;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(196, 217);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.pointsEarnedButton);
            this.Controls.Add(this.booksPurchasedTextBox);
            this.Controls.Add(this.pointsEarnedLabel);
            this.Controls.Add(this.booksPurchasedLabel);
            this.Name = "Form1";
            this.Text = "Book Club Points";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label booksPurchasedLabel;
        private System.Windows.Forms.Label pointsEarnedLabel;
        private System.Windows.Forms.TextBox booksPurchasedTextBox;
        private System.Windows.Forms.Button pointsEarnedButton;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
    }
}

