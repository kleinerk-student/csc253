﻿/**
* 29 August 2018
* CSC 253
* Kenneth Kleiner
* Calculates pay based on panny a day, doubled every day.
* Stops calculating at 76 days with doubles or decimals, but has more accuracy with decimals
* 
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PenniesForPay
{
    public partial class penniesForPay : Form
    {
        public penniesForPay()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculatePayButton_Click(object sender, EventArgs e)
        {
            decimal amountEarned = 0.01M;
            decimal amountEarnedToday = 0.01M;
            decimal amountEarnedYesterday = 0.01M;
            int daysWorked = int.Parse(daysWorkedTextBox.Text);
            int count = 1;

            if (daysWorked == 0)
            {
                amountEarnedLabel.Text = "You earned no money.  Get to work!";
            }
            else if (daysWorked == 1)
            {
                amountEarnedLabel.Text = "You earned $0.01";
            }
            else
            {
                for (count = 2; count <= daysWorked; count++)
                {
                    amountEarnedToday = amountEarnedYesterday * 2;
                    amountEarnedYesterday = amountEarnedToday;
                    amountEarned += amountEarnedToday;
                }
                amountEarnedLabel.Text = "You earned " + amountEarned.ToString("c");
            }
        }
    }
}
