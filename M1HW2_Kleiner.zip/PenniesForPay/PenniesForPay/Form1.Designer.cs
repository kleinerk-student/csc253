﻿namespace PenniesForPay
{
    partial class penniesForPay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.daysWorkedLabel = new System.Windows.Forms.Label();
            this.daysWorkedTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculatePayButton = new System.Windows.Forms.Button();
            this.amountEarnedLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // daysWorkedLabel
            // 
            this.daysWorkedLabel.AutoSize = true;
            this.daysWorkedLabel.Location = new System.Drawing.Point(13, 34);
            this.daysWorkedLabel.Name = "daysWorkedLabel";
            this.daysWorkedLabel.Size = new System.Drawing.Size(120, 13);
            this.daysWorkedLabel.TabIndex = 0;
            this.daysWorkedLabel.Text = "Enter # of days worked:";
            // 
            // daysWorkedTextBox
            // 
            this.daysWorkedTextBox.Location = new System.Drawing.Point(150, 26);
            this.daysWorkedTextBox.Name = "daysWorkedTextBox";
            this.daysWorkedTextBox.Size = new System.Drawing.Size(100, 20);
            this.daysWorkedTextBox.TabIndex = 1;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(174, 208);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculatePayButton
            // 
            this.calculatePayButton.Location = new System.Drawing.Point(16, 191);
            this.calculatePayButton.Name = "calculatePayButton";
            this.calculatePayButton.Size = new System.Drawing.Size(75, 40);
            this.calculatePayButton.TabIndex = 3;
            this.calculatePayButton.Text = "Calculate Pay";
            this.calculatePayButton.UseVisualStyleBackColor = true;
            this.calculatePayButton.Click += new System.EventHandler(this.calculatePayButton_Click);
            // 
            // amountEarnedLabel
            // 
            this.amountEarnedLabel.BackColor = System.Drawing.SystemColors.Info;
            this.amountEarnedLabel.Location = new System.Drawing.Point(16, 88);
            this.amountEarnedLabel.Name = "amountEarnedLabel";
            this.amountEarnedLabel.Size = new System.Drawing.Size(233, 23);
            this.amountEarnedLabel.TabIndex = 4;
            // 
            // penniesForPay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.amountEarnedLabel);
            this.Controls.Add(this.calculatePayButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.daysWorkedTextBox);
            this.Controls.Add(this.daysWorkedLabel);
            this.Name = "penniesForPay";
            this.Text = "Pennies for Pay";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label daysWorkedLabel;
        private System.Windows.Forms.TextBox daysWorkedTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculatePayButton;
        private System.Windows.Forms.Label amountEarnedLabel;
    }
}

