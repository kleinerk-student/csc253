﻿/**
* 20 September 2018
* CSC 253
* Kenneth Kleiner
* This program introduces the student to two-dimensional arrays
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        // variables used across methods
        int Xwins = -1;
        int Owins = -1;
        int side = -1;
        int winner = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // method to determine winner
        private void determineWinner(int sideIn)
        {
            winner = 1;
            if (sideIn == 0)
            {
                Owins = 1;
            }
            else
            {
                Xwins = 1;
            }
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            // variables used in this method
            const int ROWS = 3;
            const int COLS = 3;
            int[,] ttt_table = new int[ROWS, COLS];

            // reset variables
            winner = 0;
            Xwins = -1;
            Owins = -1;
            side = -1;

            // reset winner text
            winnerIsLabel.Text = "";

            // fill in values for table
            for (int row = 0; row < ROWS; row++)
            {
                for (int col = 0; col < COLS; col++)
                {
                    ttt_table[row, col] = rand.Next(2);
                }
            }

            // change from 0/1 to O/X
            // Is there a way to do this in a loop???
            if (ttt_table[0, 0] == 0)
                _00_Label.Text = "O";
            else
                _00_Label.Text = "X";

            if (ttt_table[0, 1] == 0)
                _01_Label.Text = "O";
            else
                _01_Label.Text = "X";

            if (ttt_table[0, 2] == 0)
                _02_Label.Text = "O";
            else
                _02_Label.Text = "X";

            if (ttt_table[1, 0] == 0)
                _10_Label.Text = "O";
            else
                _10_Label.Text = "X";

            if (ttt_table[1, 1] == 0)
                _11_Label.Text = "O";
            else
                _11_Label.Text = "X";

            if (ttt_table[1, 2] == 0)
                _12_Label.Text = "O";
            else
                _12_Label.Text = "X";

            if (ttt_table[2, 0] == 0)
                _20_Label.Text = "O";
            else
                _20_Label.Text = "X";

            if (ttt_table[2, 1] == 0)
                _21_Label.Text = "O";
            else
                _21_Label.Text = "X";

            if (ttt_table[2, 2] == 0)
                _22_Label.Text = "O";
            else
                _22_Label.Text = "X";

            // check to see if there are 3 of the same value in each row
            if (ttt_table[0, 0]==ttt_table[0, 1] && ttt_table[0, 0]==ttt_table[0, 2])
            {
                side = ttt_table[0, 0];
                determineWinner(side);
            }
            if (ttt_table[1, 0] == ttt_table[1, 1] && ttt_table[1, 0] == ttt_table[1, 2])
            {
                side = ttt_table[1, 0];
                determineWinner(side);
            }
            if (ttt_table[2, 0] == ttt_table[2, 1] && ttt_table[2, 0] == ttt_table[2, 2])
            {
                side = ttt_table[2, 0];
                determineWinner(side);
            }

            // check to see if there are 3 of the same value in each column
            if (ttt_table[0, 0] == ttt_table[1, 0] && ttt_table[0, 0] == ttt_table[2, 0])
            {
                side = ttt_table[0, 0];
                determineWinner(side);
            }
            if (ttt_table[0, 1] == ttt_table[1, 1] && ttt_table[0, 1] == ttt_table[2, 1])
            {
                side = ttt_table[0, 1];
                determineWinner(side);
            }
            if (ttt_table[0, 2] == ttt_table[1, 2] && ttt_table[0, 2] == ttt_table[2, 2])
            {
                side = ttt_table[0, 2];
                determineWinner(side);
            }

            // check to see if there are 3 of the same value in a row corner to corner
            if (ttt_table[0, 0] == ttt_table[1, 1] && ttt_table[0, 0] == ttt_table[2, 2])
            {
                side = ttt_table[0, 0];
                determineWinner(side);
            }
            if (ttt_table[0, 2] == ttt_table[1, 1] && ttt_table[0, 2] == ttt_table[2, 0])
            {
                side = ttt_table[0, 2];
                determineWinner(side);
            }

            // set text based on whether there was a winner
            if (winner == 0)
            {
                winnerIsLabel.Text = "Neither side won.";
            }
            else
            {
                if (Owins == 1)
                {
                    winnerIsLabel.Text += "O Wins! ";
                }
                if (Xwins == 1)
                {
                    winnerIsLabel.Text += "X Wins! ";
                }

            }
        }
    }
}
