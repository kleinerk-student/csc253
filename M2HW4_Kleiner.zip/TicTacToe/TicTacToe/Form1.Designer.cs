﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._00_Label = new System.Windows.Forms.Label();
            this._01_Label = new System.Windows.Forms.Label();
            this._02_Label = new System.Windows.Forms.Label();
            this._10_Label = new System.Windows.Forms.Label();
            this._11_Label = new System.Windows.Forms.Label();
            this._12_Label = new System.Windows.Forms.Label();
            this._20_Label = new System.Windows.Forms.Label();
            this._21_Label = new System.Windows.Forms.Label();
            this._22_Label = new System.Windows.Forms.Label();
            this.winnerIsLabel = new System.Windows.Forms.Label();
            this.newGameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // _00_Label
            // 
            this._00_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._00_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._00_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._00_Label.Location = new System.Drawing.Point(64, 53);
            this._00_Label.Name = "_00_Label";
            this._00_Label.Size = new System.Drawing.Size(50, 50);
            this._00_Label.TabIndex = 0;
            this._00_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _01_Label
            // 
            this._01_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._01_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._01_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._01_Label.Location = new System.Drawing.Point(139, 53);
            this._01_Label.Name = "_01_Label";
            this._01_Label.Size = new System.Drawing.Size(50, 50);
            this._01_Label.TabIndex = 1;
            this._01_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _02_Label
            // 
            this._02_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._02_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._02_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._02_Label.Location = new System.Drawing.Point(215, 53);
            this._02_Label.Name = "_02_Label";
            this._02_Label.Size = new System.Drawing.Size(50, 50);
            this._02_Label.TabIndex = 2;
            this._02_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _10_Label
            // 
            this._10_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._10_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._10_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._10_Label.Location = new System.Drawing.Point(64, 121);
            this._10_Label.Name = "_10_Label";
            this._10_Label.Size = new System.Drawing.Size(50, 50);
            this._10_Label.TabIndex = 3;
            this._10_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _11_Label
            // 
            this._11_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._11_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._11_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._11_Label.Location = new System.Drawing.Point(139, 121);
            this._11_Label.Name = "_11_Label";
            this._11_Label.Size = new System.Drawing.Size(50, 50);
            this._11_Label.TabIndex = 4;
            this._11_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _12_Label
            // 
            this._12_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._12_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._12_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._12_Label.Location = new System.Drawing.Point(215, 121);
            this._12_Label.Name = "_12_Label";
            this._12_Label.Size = new System.Drawing.Size(50, 50);
            this._12_Label.TabIndex = 5;
            this._12_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _20_Label
            // 
            this._20_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._20_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._20_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._20_Label.Location = new System.Drawing.Point(64, 189);
            this._20_Label.Name = "_20_Label";
            this._20_Label.Size = new System.Drawing.Size(50, 50);
            this._20_Label.TabIndex = 6;
            this._20_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _21_Label
            // 
            this._21_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._21_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._21_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._21_Label.Location = new System.Drawing.Point(139, 189);
            this._21_Label.Name = "_21_Label";
            this._21_Label.Size = new System.Drawing.Size(50, 50);
            this._21_Label.TabIndex = 7;
            this._21_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _22_Label
            // 
            this._22_Label.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this._22_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._22_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._22_Label.Location = new System.Drawing.Point(215, 189);
            this._22_Label.Name = "_22_Label";
            this._22_Label.Size = new System.Drawing.Size(50, 50);
            this._22_Label.TabIndex = 8;
            this._22_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // winnerIsLabel
            // 
            this.winnerIsLabel.BackColor = System.Drawing.SystemColors.Info;
            this.winnerIsLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.winnerIsLabel.Location = new System.Drawing.Point(64, 276);
            this.winnerIsLabel.Name = "winnerIsLabel";
            this.winnerIsLabel.Size = new System.Drawing.Size(201, 23);
            this.winnerIsLabel.TabIndex = 9;
            this.winnerIsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // newGameButton
            // 
            this.newGameButton.Location = new System.Drawing.Point(64, 341);
            this.newGameButton.Name = "newGameButton";
            this.newGameButton.Size = new System.Drawing.Size(75, 23);
            this.newGameButton.TabIndex = 10;
            this.newGameButton.Text = "New Game";
            this.newGameButton.UseVisualStyleBackColor = true;
            this.newGameButton.Click += new System.EventHandler(this.newGameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(189, 340);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 432);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.newGameButton);
            this.Controls.Add(this.winnerIsLabel);
            this.Controls.Add(this._22_Label);
            this.Controls.Add(this._21_Label);
            this.Controls.Add(this._20_Label);
            this.Controls.Add(this._12_Label);
            this.Controls.Add(this._11_Label);
            this.Controls.Add(this._10_Label);
            this.Controls.Add(this._02_Label);
            this.Controls.Add(this._01_Label);
            this.Controls.Add(this._00_Label);
            this.Name = "Form1";
            this.Text = "Tic-Tac-Toe";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label _00_Label;
        private System.Windows.Forms.Label _01_Label;
        private System.Windows.Forms.Label _02_Label;
        private System.Windows.Forms.Label _10_Label;
        private System.Windows.Forms.Label _11_Label;
        private System.Windows.Forms.Label _12_Label;
        private System.Windows.Forms.Label _20_Label;
        private System.Windows.Forms.Label _21_Label;
        private System.Windows.Forms.Label _22_Label;
        private System.Windows.Forms.Label winnerIsLabel;
        private System.Windows.Forms.Button newGameButton;
        private System.Windows.Forms.Button exitButton;
    }
}

