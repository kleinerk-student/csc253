﻿namespace SentenceCapitalizer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.entryLabel = new System.Windows.Forms.Label();
            this.entryTextBox = new System.Windows.Forms.TextBox();
            this.processStringButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.displayStringLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // entryLabel
            // 
            this.entryLabel.AutoSize = true;
            this.entryLabel.Location = new System.Drawing.Point(13, 13);
            this.entryLabel.Name = "entryLabel";
            this.entryLabel.Size = new System.Drawing.Size(104, 13);
            this.entryLabel.TabIndex = 0;
            this.entryLabel.Text = "Enter a string of text:";
            // 
            // entryTextBox
            // 
            this.entryTextBox.Location = new System.Drawing.Point(16, 30);
            this.entryTextBox.Name = "entryTextBox";
            this.entryTextBox.Size = new System.Drawing.Size(256, 20);
            this.entryTextBox.TabIndex = 1;
            // 
            // processStringButton
            // 
            this.processStringButton.Location = new System.Drawing.Point(16, 213);
            this.processStringButton.Name = "processStringButton";
            this.processStringButton.Size = new System.Drawing.Size(75, 37);
            this.processStringButton.TabIndex = 2;
            this.processStringButton.Text = "Process String";
            this.processStringButton.UseVisualStyleBackColor = true;
            this.processStringButton.Click += new System.EventHandler(this.processStringButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(196, 213);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 37);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(106, 213);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 37);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear form";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // displayStringLabel
            // 
            this.displayStringLabel.BackColor = System.Drawing.SystemColors.Info;
            this.displayStringLabel.Location = new System.Drawing.Point(16, 108);
            this.displayStringLabel.Name = "displayStringLabel";
            this.displayStringLabel.Size = new System.Drawing.Size(255, 23);
            this.displayStringLabel.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.displayStringLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.processStringButton);
            this.Controls.Add(this.entryTextBox);
            this.Controls.Add(this.entryLabel);
            this.Name = "Form1";
            this.Text = "Sentence Capitalizer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label entryLabel;
        private System.Windows.Forms.TextBox entryTextBox;
        private System.Windows.Forms.Button processStringButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label displayStringLabel;
    }
}

