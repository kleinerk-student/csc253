﻿/*
* 2 October 2018
* CSC 253
* Kenneth Kleiner
* This program accepts a string and capitalizes the first letter in each sentence.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SentenceCapitalizer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // this process the string
        private void processStringButton_Click(object sender, EventArgs e)
        {
            // variables used for program
            string stringIn = entryTextBox.Text;    // takes user input and puts it in a string
            string stringOut = "";                  // creates empty string to be filled in
            string letter;                          // used to store 1 character but can't use char
            bool capped = false;                    // Was last letter process capitalized
            bool firstLetter = true;                // Just in case 

            stringIn = stringIn.Trim();             // trims whitespace from front and back of string
            
            foreach (char ch in stringIn)           // processes each letter in user input string
            {
                letter = ch.ToString();             // send character to letter

                // if character is whitespace, just send character to stringOut
                if (char.IsWhiteSpace(ch))
                {
                    stringOut += letter;
                }

                // if character is a letter, check further
                if (char.IsLetter(ch))
                {
                    // if firstLetter(True) or capped(False), make upper case
                    if (firstLetter == true || capped == false)
                    {
                        stringOut += letter.ToUpper();
                        firstLetter = false;
                        capped = true;
                    }
                    else
                    {
                        // process letter without making upper case
                        stringOut += letter;
                    }
                }

                // if letter is punctuation, process further
                if (char.IsPunctuation(ch))
                {
                    // if end of sentence punctuation, set capped to false to force capitalization
                    if (letter == "." || letter == "!" || letter == "?")
                    {
                        capped = false;
                    }
                    // this processes punctuation characters to output string
                    stringOut += letter;
                }
            }
            displayStringLabel.Text = stringOut;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            entryTextBox.Text = "";
            displayStringLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
