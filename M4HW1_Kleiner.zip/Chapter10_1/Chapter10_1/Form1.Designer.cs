﻿namespace Chapter10_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataEntryLabel = new System.Windows.Forms.Label();
            this.empNumberLabel = new System.Windows.Forms.Label();
            this.empNameLabel = new System.Windows.Forms.Label();
            this.prodShiftLabel = new System.Windows.Forms.Label();
            this.payRateLabel = new System.Windows.Forms.Label();
            this.empNumberTextBox = new System.Windows.Forms.TextBox();
            this.empNameTextBox = new System.Windows.Forms.TextBox();
            this.shiftNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.payRateTextBox = new System.Windows.Forms.TextBox();
            this.createProdWorkerButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.displayEmpDataLabel = new System.Windows.Forms.Label();
            this.displayEmpNameLabel = new System.Windows.Forms.Label();
            this.displayEmpNumberLabel = new System.Windows.Forms.Label();
            this.displayShiftLabel = new System.Windows.Forms.Label();
            this.displayPayRateLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.shiftNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // dataEntryLabel
            // 
            this.dataEntryLabel.AutoSize = true;
            this.dataEntryLabel.Location = new System.Drawing.Point(13, 13);
            this.dataEntryLabel.Name = "dataEntryLabel";
            this.dataEntryLabel.Size = new System.Drawing.Size(163, 13);
            this.dataEntryLabel.TabIndex = 0;
            this.dataEntryLabel.Text = "Enter data for Production Worker";
            // 
            // empNumberLabel
            // 
            this.empNumberLabel.AutoSize = true;
            this.empNumberLabel.Location = new System.Drawing.Point(13, 49);
            this.empNumberLabel.Name = "empNumberLabel";
            this.empNumberLabel.Size = new System.Drawing.Size(96, 13);
            this.empNumberLabel.TabIndex = 1;
            this.empNumberLabel.Text = "Employee Number:";
            // 
            // empNameLabel
            // 
            this.empNameLabel.AutoSize = true;
            this.empNameLabel.Location = new System.Drawing.Point(13, 79);
            this.empNameLabel.Name = "empNameLabel";
            this.empNameLabel.Size = new System.Drawing.Size(87, 13);
            this.empNameLabel.TabIndex = 2;
            this.empNameLabel.Text = "Employee Name:";
            // 
            // prodShiftLabel
            // 
            this.prodShiftLabel.AutoSize = true;
            this.prodShiftLabel.Location = new System.Drawing.Point(13, 109);
            this.prodShiftLabel.Name = "prodShiftLabel";
            this.prodShiftLabel.Size = new System.Drawing.Size(108, 13);
            this.prodShiftLabel.TabIndex = 3;
            this.prodShiftLabel.Text = "Shift (1-Day, 2-Night):";
            // 
            // payRateLabel
            // 
            this.payRateLabel.AutoSize = true;
            this.payRateLabel.Location = new System.Drawing.Point(13, 139);
            this.payRateLabel.Name = "payRateLabel";
            this.payRateLabel.Size = new System.Drawing.Size(54, 13);
            this.payRateLabel.TabIndex = 4;
            this.payRateLabel.Text = "Pay Rate:";
            // 
            // empNumberTextBox
            // 
            this.empNumberTextBox.Location = new System.Drawing.Point(170, 46);
            this.empNumberTextBox.Name = "empNumberTextBox";
            this.empNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.empNumberTextBox.TabIndex = 5;
            // 
            // empNameTextBox
            // 
            this.empNameTextBox.Location = new System.Drawing.Point(170, 76);
            this.empNameTextBox.Name = "empNameTextBox";
            this.empNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.empNameTextBox.TabIndex = 6;
            // 
            // shiftNumericUpDown
            // 
            this.shiftNumericUpDown.Location = new System.Drawing.Point(170, 107);
            this.shiftNumericUpDown.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.shiftNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.shiftNumericUpDown.Name = "shiftNumericUpDown";
            this.shiftNumericUpDown.Size = new System.Drawing.Size(120, 20);
            this.shiftNumericUpDown.TabIndex = 7;
            this.shiftNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // payRateTextBox
            // 
            this.payRateTextBox.Location = new System.Drawing.Point(170, 136);
            this.payRateTextBox.Name = "payRateTextBox";
            this.payRateTextBox.Size = new System.Drawing.Size(100, 20);
            this.payRateTextBox.TabIndex = 8;
            // 
            // createProdWorkerButton
            // 
            this.createProdWorkerButton.Location = new System.Drawing.Point(16, 194);
            this.createProdWorkerButton.Name = "createProdWorkerButton";
            this.createProdWorkerButton.Size = new System.Drawing.Size(75, 50);
            this.createProdWorkerButton.TabIndex = 9;
            this.createProdWorkerButton.Text = "Create Production Worker";
            this.createProdWorkerButton.UseVisualStyleBackColor = true;
            this.createProdWorkerButton.Click += new System.EventHandler(this.createProdWorkerButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(367, 194);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 50);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // displayEmpDataLabel
            // 
            this.displayEmpDataLabel.AutoSize = true;
            this.displayEmpDataLabel.Location = new System.Drawing.Point(342, 13);
            this.displayEmpDataLabel.Name = "displayEmpDataLabel";
            this.displayEmpDataLabel.Size = new System.Drawing.Size(79, 13);
            this.displayEmpDataLabel.TabIndex = 11;
            this.displayEmpDataLabel.Text = "Employee Data";
            // 
            // displayEmpNameLabel
            // 
            this.displayEmpNameLabel.BackColor = System.Drawing.SystemColors.Info;
            this.displayEmpNameLabel.Location = new System.Drawing.Point(342, 73);
            this.displayEmpNameLabel.Name = "displayEmpNameLabel";
            this.displayEmpNameLabel.Size = new System.Drawing.Size(100, 23);
            this.displayEmpNameLabel.TabIndex = 12;
            // 
            // displayEmpNumberLabel
            // 
            this.displayEmpNumberLabel.BackColor = System.Drawing.SystemColors.Info;
            this.displayEmpNumberLabel.Location = new System.Drawing.Point(342, 43);
            this.displayEmpNumberLabel.Name = "displayEmpNumberLabel";
            this.displayEmpNumberLabel.Size = new System.Drawing.Size(100, 23);
            this.displayEmpNumberLabel.TabIndex = 13;
            // 
            // displayShiftLabel
            // 
            this.displayShiftLabel.BackColor = System.Drawing.SystemColors.Info;
            this.displayShiftLabel.Location = new System.Drawing.Point(342, 104);
            this.displayShiftLabel.Name = "displayShiftLabel";
            this.displayShiftLabel.Size = new System.Drawing.Size(100, 23);
            this.displayShiftLabel.TabIndex = 14;
            this.displayShiftLabel.Click += new System.EventHandler(this.displayShiftLabel_Click);
            // 
            // displayPayRateLabel
            // 
            this.displayPayRateLabel.BackColor = System.Drawing.SystemColors.Info;
            this.displayPayRateLabel.Location = new System.Drawing.Point(342, 133);
            this.displayPayRateLabel.Name = "displayPayRateLabel";
            this.displayPayRateLabel.Size = new System.Drawing.Size(100, 23);
            this.displayPayRateLabel.TabIndex = 15;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(190, 194);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 50);
            this.clearButton.TabIndex = 16;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 268);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.displayPayRateLabel);
            this.Controls.Add(this.displayShiftLabel);
            this.Controls.Add(this.displayEmpNumberLabel);
            this.Controls.Add(this.displayEmpNameLabel);
            this.Controls.Add(this.displayEmpDataLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.createProdWorkerButton);
            this.Controls.Add(this.payRateTextBox);
            this.Controls.Add(this.shiftNumericUpDown);
            this.Controls.Add(this.empNameTextBox);
            this.Controls.Add(this.empNumberTextBox);
            this.Controls.Add(this.payRateLabel);
            this.Controls.Add(this.prodShiftLabel);
            this.Controls.Add(this.empNameLabel);
            this.Controls.Add(this.empNumberLabel);
            this.Controls.Add(this.dataEntryLabel);
            this.Name = "Form1";
            this.Text = "Production Worker";
            ((System.ComponentModel.ISupportInitialize)(this.shiftNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dataEntryLabel;
        private System.Windows.Forms.Label empNumberLabel;
        private System.Windows.Forms.Label empNameLabel;
        private System.Windows.Forms.Label prodShiftLabel;
        private System.Windows.Forms.Label payRateLabel;
        private System.Windows.Forms.TextBox empNumberTextBox;
        private System.Windows.Forms.TextBox empNameTextBox;
        private System.Windows.Forms.NumericUpDown shiftNumericUpDown;
        private System.Windows.Forms.TextBox payRateTextBox;
        private System.Windows.Forms.Button createProdWorkerButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label displayEmpDataLabel;
        private System.Windows.Forms.Label displayEmpNameLabel;
        private System.Windows.Forms.Label displayEmpNumberLabel;
        private System.Windows.Forms.Label displayShiftLabel;
        private System.Windows.Forms.Label displayPayRateLabel;
        private System.Windows.Forms.Button clearButton;
    }
}

