﻿/*
* 25 October 2018
* CSC 253
* Kenneth Kleiner
* First use of Inheritance
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter10_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetProdEmpData(ProductionWorker prodWorker)
        {
            prodWorker.Number = int.Parse(empNumberTextBox.Text);
            prodWorker.Name = empNameTextBox.Text;
            prodWorker.Shift = int.Parse(shiftNumericUpDown.Value.ToString());
            prodWorker.PayRate = decimal.Parse(payRateTextBox.Text);
        }

        private void createProdWorkerButton_Click(object sender, EventArgs e)
        {
            ProductionWorker newEmp = new ProductionWorker();
            GetProdEmpData(newEmp);

            displayEmpNameLabel.Text = newEmp.Name;
            displayEmpNumberLabel.Text = newEmp.Number.ToString();
            displayPayRateLabel.Text = newEmp.PayRate.ToString();
            if (newEmp.Shift == 1)
            {
                displayShiftLabel.Text = "Day";
            }
            else
            {
                displayShiftLabel.Text = "Night";
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void displayShiftLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
