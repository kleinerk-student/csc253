﻿/*
* 25 October 2018
* CSC 253
* Kenneth Kleiner
* Another look at inheritance
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter_10_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GetSupervisorData(ShiftSupervisor supervisor)
        {
            supervisor.Number = int.Parse(empNumberTextBox.Text);
            supervisor.Name = empNameTextBox.Text;
            supervisor.Salary = decimal.Parse(salaryTextBox.Text);
            supervisor.Bonus = decimal.Parse(prodBonusTextBox.Text);
        }

        private void processButton_Click(object sender, EventArgs e)
        {
            ShiftSupervisor newSuper = new ShiftSupervisor();
            GetSupervisorData(newSuper);

            displayNameLabel.Text = newSuper.Name;
            displayNumberLabel.Text = newSuper.Number.ToString();
            displaySalaryLabel.Text = newSuper.Salary.ToString();
            displayBonusLabel.Text = newSuper.Bonus.ToString();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clear display areas
            displayNameLabel.Text = "";
            displayNumberLabel.Text = "";
            displaySalaryLabel.Text = "";
            displayBonusLabel.Text = "";

            // clear input boxes
            empNumberTextBox.Text = "";
            empNameTextBox.Text = "";
            salaryTextBox.Text = "";
            prodBonusTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
