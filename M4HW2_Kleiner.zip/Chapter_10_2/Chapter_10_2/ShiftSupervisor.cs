﻿/*
* 25 October 2018
* CSC 253
* Kenneth Kleiner
* Another look at inheritance
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter_10_2
{
    class ShiftSupervisor : Employee
    {
        // Fields

        public decimal Salary { get; set; }
        public decimal Bonus { get; set; }

        public ShiftSupervisor()
        {
            Salary = 0.00m;
            Bonus = 0.00m;
        }


    }
}
